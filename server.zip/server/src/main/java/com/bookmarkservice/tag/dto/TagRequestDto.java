package com.bookmarkservice.tag.dto;

import lombok.Getter;

@Getter
public class TagRequestDto {
    private String name;
}
